package com.example.pictureviewer

import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var editTextUrl: EditText
    private lateinit var textViewStatus: TextView

    private val pictures = listOf(R.drawable.sample_picture, R.drawable.sample_picture_2)
    private var pictureIndex = 0

    private val scaleTypes = listOf(
        ImageView.ScaleType.FIT_CENTER,
        ImageView.ScaleType.CENTER_CROP,
        ImageView.ScaleType.CENTER_INSIDE,
        ImageView.ScaleType.FIT_XY
    )
    private var scaleIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        editTextUrl = findViewById(R.id.urlEditText)
        textViewStatus = findViewById(R.id.textViewStatus)

        findViewById<Button>(R.id.btnLoadManual).setOnClickListener { loadImageManually() }
        findViewById<Button>(R.id.btnLoadGlide).setOnClickListener { loadImageWithGlide() }

        findViewById<Button>(R.id.buttonNextPicture).setOnClickListener { showNextPicture() }
        findViewById<Button>(R.id.buttonScaleType).setOnClickListener { nextScaleType() }
        findViewById<Button>(R.id.buttonReset).setOnClickListener { resetAll() }
    }

    private fun showNextPicture() {
        pictureIndex = (pictureIndex + 1) % pictures.size
        imageView.setImageResource(pictures[pictureIndex])
        textViewStatus.setText(R.string.status_ready)
    }

    private fun nextScaleType() {
        scaleIndex = (scaleIndex + 1) % scaleTypes.size
        imageView.scaleType = scaleTypes[scaleIndex]
        textViewStatus.text = scaleTypes[scaleIndex].name
    }

    private fun resetAll() {
        pictureIndex = 0
        imageView.setImageResource(pictures[pictureIndex])
        editTextUrl.setText(R.string.default_url)
        textViewStatus.setText(R.string.status_ready)
    }

    private fun readAddress(): String? {
        val address = editTextUrl.text.toString().trim()
        if (address.isEmpty()) {
            Toast.makeText(this, R.string.error_empty_url, Toast.LENGTH_SHORT).show()
            return null
        }
        return address
    }

    private fun loadImageManually() {
        val address = readAddress() ?: return
        Thread {
            try {
                val connection = URL(address).openConnection()
                connection.connect()
                val input = connection.getInputStream()
                val bitmap = BitmapFactory.decodeStream(input)
                input.close()
                runOnUiThread { imageView.setImageBitmap(bitmap) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun loadImageWithGlide() {
        val address = readAddress() ?: return
        Glide.with(this)
            .load(address)
            .circleCrop()
            .into(imageView)
    }
}